//
//  TVBeginSignVC.h
//  TVSignFrameworkDemo
//
//  Created by wz on 16/5/11.
//  Copyright © 2016年 Timevale. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVBeginSignVC : UIViewController

@property (nonatomic, copy) NSString* accountUid; //用户uid

@end

