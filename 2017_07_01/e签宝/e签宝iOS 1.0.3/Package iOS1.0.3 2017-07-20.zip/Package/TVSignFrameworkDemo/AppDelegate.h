//
//  AppDelegate.h
//  TVSignFrameworkDemo
//
//  Created by wz on 16/5/11.
//  Copyright © 2016年 Timevale. All rights reserved.
//

#import <UIKit/UIKit.h>

#define SIGN_SERVER_ENVIROMENT 2

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

