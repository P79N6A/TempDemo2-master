//
//  AppDelegate.h
//  FlickerNumber
//
//  Created by yulong on 16/2/22.
//  Copyright © 2016年 xiaoyulong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    /**
     球叮足球
     https://itunes.apple.com/cn/app/qiu-ding-zu-qiu/id939083762?mt=8
     */
    
}

@property (strong, nonatomic) UIWindow *window;

@end

