//
//  ViewController.h
//  FlickerNumber
//
//  Created by yulong on 16/2/22.
//  Copyright © 2016年 xiaoyulong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

