//
//  DetailVC1.m
//  FlickerNumber
//
//  Created by yulong on 16/2/22.
//  Copyright © 2016年 xiaoyulong. All rights reserved.
//

#import "DetailVC1.h"
#import "UILabel+FlickerNumber.h"

@interface DetailVC1 ()

@property (nonatomic, strong) UIButton *btn;

@property (nonatomic, strong) UILabel *numberLabel;

@end

@implementation DetailVC1

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setUI];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 创建UI

- (void)setUI
{
    self.view.backgroundColor = [UIColor whiteColor];
    
    if ([UIDevice currentDevice].systemVersion.floatValue >= 7.0)
    {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.extendedLayoutIncludesOpaqueBars = NO;
    }
    [self.view addSubview:self.numberLabel];
    [self.view addSubview:self.btn];
}

#pragma mark - setter, getter

- (UILabel *)numberLabel
{
    if (_numberLabel == nil)
    {
        _numberLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 50, 100, 30)];
        _numberLabel.backgroundColor = [UIColor yellowColor];
        _numberLabel.textAlignment = NSTextAlignmentCenter;
        _numberLabel.numberOfLines = 0;
    }
    return _numberLabel;
}

- (UIButton *)btn
{
    if (_btn == nil)
    {
        _btn = [UIButton buttonWithType:UIButtonTypeCustom];
        _btn.frame = CGRectMake(100, 200, 100, 30);
        _btn.backgroundColor = [UIColor yellowColor];
        [_btn setTitle:@"点击" forState:UIControlStateNormal];
        [_btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _btn;
}

#pragma mark - 按钮响应事件

- (void)click:(UIButton *)sender
{
//    [self.numberLabel dd_setNumber:@(1234567)];
    [self.numberLabel dd_setNumber:@(1234567) formatter:nil];
}

#pragma mark - 网络请求



#pragma mark - 代理方法

#pragma mark -


- (NSNumberFormatter *)myFormatter
{
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    formatter.formatterBehavior = NSNumberFormatterBehavior10_4;
    
//    // 十六进制
//    formatter.numberStyle = NSNumberFormatterDecimalStyle;
//    
//    // 百分号的
//    formatter.numberStyle = NSNumberFormatterPercentStyle;
    
//    // 科学计数法的 1234567 计为 1.234567E6
//    formatter.numberStyle = NSNumberFormatterScientificStyle;
    
    // 手机系统为简体中文时 看到的是汉语 一百二十三万四千五百六十七
    // 手机系统为英语时  看到的是 one million two hundred thirty - four...
    formatter.numberStyle = NSNumberFormatterSpellOutStyle;
    
//    formatter.numberStyle = NSNumberFormatterOrdinalStyle;
    return formatter;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
